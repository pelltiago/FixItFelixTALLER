package ventana.panel;

public abstract class EstadoPanel {

	public abstract boolean puedoArreglar(Panel panel);
	public abstract boolean puedoRomper(Panel panel);

}
