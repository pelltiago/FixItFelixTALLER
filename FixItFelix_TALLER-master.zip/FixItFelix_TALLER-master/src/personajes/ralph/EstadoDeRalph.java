package personajes.ralph;

public enum EstadoDeRalph {
	NORMAL, TIRANDO, MOVIENDOI1, MOVIENDOI2, ROMPIENDO, MOVIENDOD1, MOVIENDOD2,
}
