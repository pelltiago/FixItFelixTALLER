package personajes.felix;

public enum EstadoDeFelix {
	MUERTO, NORMAL, MOVIENDO, ARREGLANDO1, ARREGLANDO2, TOMANDOPASTEL
}