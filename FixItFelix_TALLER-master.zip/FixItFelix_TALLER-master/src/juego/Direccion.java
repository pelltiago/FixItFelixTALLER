package juego;

public enum Direccion {
		ARRIBA, ABAJO, IZQUIERDA, DERECHA
}
