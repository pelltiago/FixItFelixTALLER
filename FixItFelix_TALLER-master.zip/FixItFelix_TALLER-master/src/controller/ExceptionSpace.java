package controller;

public class ExceptionSpace extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
