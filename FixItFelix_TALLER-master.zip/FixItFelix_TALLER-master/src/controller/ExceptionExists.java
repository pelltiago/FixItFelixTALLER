package controller;

public class ExceptionExists extends Exception{ // Excepcion propia 1

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
